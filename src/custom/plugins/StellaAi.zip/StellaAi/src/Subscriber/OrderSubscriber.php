<?php declare(strict_types=1);


namespace StellaAi\Subscriber;


use Shopware\Core\Checkout\Cart\Event\CheckoutOrderPlacedEvent;
use Shopware\Core\Checkout\Cart\Order\CartConvertedEvent;
use Shopware\Core\Checkout\Order\Aggregate\OrderLineItem\OrderLineItemEntity;
use Shopware\Core\Checkout\Order\OrderEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class OrderSubscriber implements EventSubscriberInterface
{
    private SystemConfigService $systemConfigService;

    private string $apiEndpoint = 'https://tracking-api-1024057789892.europe-west3.run.app/v1/purchase/createOrder';

    public function __construct(SystemConfigService $configService)
    {
        $this->systemConfigService = $configService;

    }

    public static function getSubscribedEvents(): array
    {
        return [
            CheckoutOrderPlacedEvent::class => 'onCheckoutOrderPlaced',
        ];
    }

    public function onCheckoutOrderPlaced(CheckoutOrderPlacedEvent $event): void
    {
        $order = $event->getOrder();
        $context = $event->getContext();

        $payload = $this->buildPayload($order, $context);

        if ($payload) {
            $this->sendPurchaseToApi($payload);
        }
    }

    private function buildPayload(OrderEntity $order, Context $context): ?array
    {
        $asksetellaProducts = [];
        $lineItems = [];
        foreach ($order->getLineItems()->getElements() as $lineItem) {
            /** @var OrderLineItemEntity $lineItem */
            $lineItems[] = [
                'id' => $lineItem->getId(),
                'name' => $lineItem->getLabel(),
                'title' => $lineItem->getPayload()['productName'] ?? '',
                'variant_title' => $lineItem->getPayload()['variantName'] ?? '',
                'product_id' => $lineItem->getReferencedId() ?? '',
                'variant_id' => $lineItem->getPayload()['variantId'] ?? '',
                'price' => (string)$lineItem->getTotalPrice(),
                'quantity' => $lineItem->getQuantity(),
                'total_discount' => '0.00', // Optional, adjust if necessary
                'sku' => $lineItem->getPayload()['productNumber'] ?? '',
                'vendor' => $lineItem->getPayload()['manufacturer'] ?? '',
            ];


            if ($lineItem->getPayload()['stella-ai-product'] ?? false) {
                $asksetellaProducts[] = [
                    'id' => $lineItem->getReferencedId(),
                ];
            }
        }

        return [
            'created_at' => $order->getOrderDateTime()->format(DATE_ISO8601),
            'id' => $order->getId(),
            'order_number' => $order->getOrderNumber(),
            'currency' => $order->getCurrency()->getIsoCode(),
            'line_items' => $lineItems,
            'note_attributes' => [
                'name' => '__ask_stella_tracking',
                'value' => json_encode($asksetellaProducts),
            ], // Adjust if note attributes are available
            'total_discounts' => '0.00',
            'total_line_items_price' => (string)$order->getAmountNet(),
            'total_shipping_price' => (string)$order->getShippingCosts()->getTotalPrice(),
            'total_price' => (string)$order->getAmountTotal(),
            'total_tax' => (string)($order->getAmountTotal() - $order->getAmountNet()),
            'client_details' => [
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            ],
        ];
    }

    private function sendPurchaseToApi(array $payload): void
    {
        try {
            $curl = curl_init();

            $headers = [
                'Content-Type: application/json',
                'X-Shop-Domain: ' . $this->systemConfigService->get('StellaAi.config.StellaAIShopDomain'),
            ];

            $options = [
                CURLOPT_URL => $this->apiEndpoint,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_POSTFIELDS => json_encode($payload),
            ];

            curl_setopt_array($curl, $options);

            $response = curl_exec($curl);

            if (curl_errno($curl)) {
                // Handle cURL error
                $error = curl_error($curl);
                curl_close($curl);
                throw new \Exception('cURL Error: ' . $error);
            }

            curl_close($curl);

        } catch (\Exception $e) {
            // Log the error or handle it appropriately
        }
    }
}
