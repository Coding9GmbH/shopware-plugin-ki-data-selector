<?php

namespace StellaAi\Subscriber;

use Shopware\Core\Content\Product\SalesChannel\SalesChannelProductEntity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\Struct\ArrayStruct;
use Shopware\Storefront\Page\Product\ProductPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ProductPageSubscriber implements EventSubscriberInterface
{
    private EntityRepository $productRepository;

    public function __construct(EntityRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ProductPageLoadedEvent::class => 'onProductPageLoaded',
        ];
    }

    public function onProductPageLoaded(ProductPageLoadedEvent $event): void
    {
        $page = $event->getPage();
        $product = $page->getProduct();

        if (!$product instanceof SalesChannelProductEntity) {
            return;
        }

        $criteria = new \Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria();
        $criteria->addAssociation('options.group');
        $criteria->addFilter(new \Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter('parentId', $product->getParentId()));

        $variants = $this->productRepository->search($criteria, $event->getContext());

        $variantData = [];
        foreach ($variants as $variant) {

            $variantName = [];
            foreach ($variant->getOptions() as $option) {
                $variantName[] = $option->getGroup()->getName() . ': ' . $option->getName();
            }
            $variantData[] = [
                'id' => $variant->getId(),
                'ean' => $variant->getEan(),
                'name' => implode(' - ', $variantName),
            ];
        }

        $variantsStruct = new ArrayStruct($variantData);
        $product->addExtension('variants', $variantsStruct);
    }
}
