import template from './sw-cms-el-preview-stella-ai-iframe.html.twig';
import './sw-cms-el-preview-stella-ai-iframe.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-stella-ai-iframe', {
    template
});
