import template from './sw-cms-el-config-stella-ai-iframe.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-el-config-stella-ai-iframe', {
  template,
});
