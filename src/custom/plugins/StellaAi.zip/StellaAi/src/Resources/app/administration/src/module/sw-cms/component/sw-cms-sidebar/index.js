import template from './sw-cms-sidebar.html.twig';

const { Component } = Shopware;
Component.override('sw-cms-sidebar', {
  template,
});
