import './component';
import './config';
import './preview';

Shopware.Service('cmsService').registerCmsElement({
    name: 'stella-ai-iframe',
    label: 'sw-cms.elements.stella-ai-iframe.label',
    component: 'sw-cms-el-stella-ai-iframe',
    configComponent: 'sw-cms-el-config-stella-ai-iframe',
    previewComponent: 'sw-cms-el-preview-stella-ai-iframe',
    disabledConfigInfoTextKey: 'sw-cms.elements.sidebarCategoryNavigation.infoText.navigationElement',
});
