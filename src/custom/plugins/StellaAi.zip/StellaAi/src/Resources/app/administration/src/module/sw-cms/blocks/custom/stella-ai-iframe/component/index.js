import template from './sw-cms-block-stella-ai-iframe.html.twig';
import './sw-cms-block-stella-ai-iframe.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-stella-ai-iframe', {
    template
});
