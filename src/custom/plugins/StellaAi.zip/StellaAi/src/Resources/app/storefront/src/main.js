// import PdpPersonalizationPlugin from './plugin/pdp-personalization.plugin';

const { PluginManager } = window;

// Register new plugins
// PluginManager.register('PdpPersonalizationPlugin', PdpPersonalizationPlugin, '[data-pdp-widget]');


