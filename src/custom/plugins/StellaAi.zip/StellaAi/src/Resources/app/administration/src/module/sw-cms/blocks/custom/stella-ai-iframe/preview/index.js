import template from './sw-cms-preview-stella-ai-iframe.html.twig';
import './sw-cms-preview-stella-ai-iframe.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-stella-ai-iframe', {
  template
});
