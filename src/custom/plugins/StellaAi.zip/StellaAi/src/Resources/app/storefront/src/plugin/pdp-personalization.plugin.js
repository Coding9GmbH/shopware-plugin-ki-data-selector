import Plugin from 'src/plugin-system/plugin.class';

export default class PdpPersonalizationPlugin extends Plugin {
    init() {
        this.widget = document.querySelector('.stella-ai-personalization');
        this.snippetSearchText = this.widget.getAttribute('data-snippet-search-text');
        this.snippetHelpText = this.widget.getAttribute('data-snippet-help-text');
        this.snippetYourRecommendationText = this.widget.getAttribute('data-snippet-your-recommendation-text');

        if (!this.widget) {
            console.error('PDP Widget element not found!');
            return;
        }
        this.recommendedProducts = localStorage.getItem("askstella_recommended_products");

        console.log(this.recommendedProducts);
        if (!this.recommendedProducts) {
            this.showAnalysisRecommendation();
        } else {
            this.recommendedProducts = JSON.parse(this.recommendedProducts);
            this.displayRecommendations();
        }
    }

    showAnalysisRecommendation() {
        // search text and help text instead of plain text to inner html

        this.widget.innerHTML = `
    <p>${this.snippetSearchText}<br/>
        <a 
            data-bs-toggle="modal" 
            data-bs-target="#stella-ai-product-finder">
            ${this.snippetHelpText}
        </a>
    </p>
`;
    }

    displayRecommendations() {
        this.widget.innerHTML = `
            <div>
                <p>${this.snippetYourRecommendationText}</p>
                <ul id="recommended-list"></ul>
            </div>
        `;

        let recommendationFound = false;
        const ul = this.widget.querySelector("#recommended-list");

        this.variations = this.getVariationsFromWidget();

        for (let recommendedProduct of this.recommendedProducts) {
            for (let variation of this.variations) {
                if (variation.id === recommendedProduct.variant_id) {
                    const li = document.createElement("li");
                    // add variation name to list with link
                    li.innerHTML = `<a href="${recommendedProduct.link}">${variation.name}</a>`;
                    ul.appendChild(li);
                    recommendationFound = true;
                }
            }
        }

        if (recommendationFound) {
            this.widget.style.display = "block";
        } else {
            this.widget.style.display = "none";
        }
    }

    getVariationsFromWidget() {
        const dataAttribute = this.widget.getAttribute('data-current-product-id');
        if (!dataAttribute) {
            console.error('No data-current-product-id attribute found on the widget!');
            return [];
        }

        const parsedData = JSON.parse(dataAttribute);
        return Object.values(parsedData)
            .filter(variation => variation.id) // Filter out invalid entries
            .map(variation => ({
                id: variation.id, ean: variation.ean || 'EAN not available', // Default value for missing EANs
                name: variation.name || 'Name not available' // Default value for missing names
            }));
    }

}