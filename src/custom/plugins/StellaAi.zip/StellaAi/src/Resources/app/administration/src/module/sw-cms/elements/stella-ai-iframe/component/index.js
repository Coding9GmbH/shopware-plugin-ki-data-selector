import template from './sw-cms-el-stella-ai-iframe.html.twig';
import './sw-cms-el-stella-ai-iframe.scss';

const { Component, Mixin } = Shopware;

Component.register('sw-cms-el-stella-ai-iframe', {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('placeholder'),
    ],

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('stella-ai-iframe');
        },
    },
});