import './component';
import './preview';

Shopware.Service('cmsService').registerCmsBlock({
    name: 'stella-ai-iframe',
    label: 'sw-cms.blocks.stella-ai-iframe.label',
    category: 'custom',
    component: 'sw-cms-block-stella-ai-iframe',
    previewComponent: 'sw-cms-preview-stella-ai-iframe',
    defaultConfig: {
        marginBottom: '0px',
        marginTop: '0px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        'stella-ai-iframe': {
            type: 'stella-ai-iframe',
            default: {}
        }
    }
});
