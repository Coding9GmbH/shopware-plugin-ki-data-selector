<?php

namespace StellaAi\Storefront\Controller;


use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\NotFilter;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Controller\StorefrontController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route(defaults: ['_routeScope' => ['storefront']])]
class ProductFeedController extends StorefrontController
{
    /**
     * @var EntityRepository
     */
    private $productRepository;

    public function __construct(EntityRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/feed/csv", name="frontend.feed.csv", methods={"GET"})
     */
    #[Route(path: '/feed/askstella-csv', name: 'frontend.feed.askstella-csv', methods: ['GET'])]
    public function csvFeed(Request $request, SalesChannelContext $context): Response
    {
        $criteria = new Criteria();
        $criteria->addFilter(
            new NotFilter(
                NotFilter::CONNECTION_AND,
                [new EqualsFilter('parentId', null)]
            )
        );
        $criteria->addAssociation('cover.media');
        $criteria->addAssociation('media.media');

        $result = $this->productRepository->search($criteria, $context->getContext());
        $products = $result->getEntities();

        $handle = fopen('php://temp', 'r+');
        fputcsv($handle, [
            'id',
            'parentId',
            'productNumber',
            'name',
            'price',
            'compareAtPrice',
            'shortDescription',
            'images',
            'url'
        ]);

        /** @var ProductEntity $product */
        foreach ($products as $product) {
            $id = $product->getId();
            $parentId = $product->getParentId();
            $productNumber = $product->getProductNumber();
            $name = $product->getTranslation('name');
            $shortDescription = $product->getTranslation('description');

            $price = null;
            $compareAtPrice = null;
            $prices = $product->getPrice();
            if ($prices && $prices->first()) {
                $price = $prices->first()->getGross();
                if ($prices->first()->getListPrice()) {
                    $compareAtPrice = $prices->first()->getListPrice()->getGross();
                }
            }

            $images = [];
            if ($product->getCover() && $product->getCover()->getMedia()) {
                $media = $product->getCover()->getMedia();
                if ($media->getUrl()) {
                    $images[] = $media->getUrl();
                }
            }
            if ($product->getMedia()) {
                foreach ($product->getMedia() as $mediaEntity) {
                    if ($mediaEntity->getMedia() && $mediaEntity->getMedia()->getUrl()) {
                        $images[] = $mediaEntity->getMedia()->getUrl();
                    }
                }
            }

            $images = array_unique($images);
            $imagesString = implode(',', $images);

            $salesChannel = $context->getSalesChannel();
            $domain = null;

            if ($salesChannel && $salesChannel->getDomains() && $salesChannel->getDomains()->first()) {
                $domain = $salesChannel->getDomains()->first()->getUrl();
            }

            if (!$domain) {
                $domain = 'https://default-shop.com'; // Fallback, falls keine Domain verfügbar ist
            }

            $url = sprintf('%s/detail/%s', rtrim($domain, '/'), $id);

            fputcsv($handle, [
                $id,
                $parentId,
                $productNumber,
                $name,
                $price,
                $compareAtPrice,
                $shortDescription,
                $imagesString,
                $url
            ]);
        }

        rewind($handle);
        $csvContent = stream_get_contents($handle);
        fclose($handle);

        $response = new Response($csvContent);
        $response->headers->set('Content-Type', 'text/csv');
        $response->headers->set('Content-Disposition', 'attachment; filename="feed.csv"');

        return $response;
    }
}
