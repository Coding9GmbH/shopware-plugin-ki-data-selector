<?php declare(strict_types=1);

namespace StellaAi\Storefront\Controller;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Cart\CartException;
use Shopware\Core\Checkout\Cart\Error\Error;
use Shopware\Core\Checkout\Cart\LineItem\LineItem;
use Shopware\Core\Checkout\Cart\LineItemFactoryRegistry;
use Shopware\Core\Checkout\Cart\SalesChannel\CartService;
use Shopware\Core\Checkout\Order\OrderEntity;
use Shopware\Core\Content\Product\Exception\ProductNotFoundException;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Sorting\FieldSorting;
use Shopware\Core\Framework\Feature;
use Shopware\Core\Framework\Routing\RoutingException;
use Shopware\Core\Framework\Validation\DataBag\RequestDataBag;
use Shopware\Core\Profiling\Profiler;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Controller\CheckoutController as Original;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route(defaults: ['_routeScope' => ['storefront']])]
class CheckoutController extends Original
{
    private Original $decorated;

    private CartService $cartService;

    private EntityRepository $orderRepository;

    private LineItemFactoryRegistry $lineItemFactoryRegistry;
    private EntityRepository $productRepository;

    public function __construct(
        Original                $decorated,
        CartService             $cartService,
        EntityRepository        $orderRepository,
        LineItemFactoryRegistry $lineItemFactoryRegistry,
        EntityRepository        $productRepository
    )
    {
        $this->decorated = $decorated;
        $this->cartService = $cartService;
        $this->orderRepository = $orderRepository;
        $this->lineItemFactoryRegistry = $lineItemFactoryRegistry;
        $this->productRepository = $productRepository;
    }

    public function cartPage(Request $request, SalesChannelContext $context): Response
    {
        return $this->decorated->cartPage($request, $context);
    }

    /**
     * requires the provided items in the following form
     * 'lineItems' => [
     *     'anyKey' => [
     *         'id' => 'someKey'
     *         'quantity' => 2,
     *         'type' => 'someType'
     *     ],
     *     'randomKey' => [
     *         'id' => 'otherKey'
     *         'quantity' => 2,
     *         'type' => 'otherType'
     *     ]
     * ]
     */
    #[Route(path: '/checkout/stella-ai/add', name: 'frontend.checkout.stella-ai.line-item.add', defaults: ['XmlHttpRequest' => true], methods: ['POST'])]
    public function addLineItems(Cart $cart, RequestDataBag $requestDataBag, Request $request, SalesChannelContext $context): Response
    {
        /** @var RequestDataBag|null $lineItems */
        $lineItems = $requestDataBag->get('items');
        if (!$lineItems) {
            throw RoutingException::missingRequestParameter('items');
        }


        try {
            $items = [];
            $stellaAIAddedProduct = null;
            /** @var RequestDataBag $lineItemData */
            foreach ($lineItems as $lineItemData) {
                try {
                    //get product id by id number over criteria and repository
                    $criteria = new Criteria();
                    $criteria->addFilter(new EqualsFilter('id', $lineItemData->get('id')));
                    $criteria->setLimit(1);
                    $product = $this->productRepository->search($criteria, $context->getContext())->first();

                    $item = $this->lineItemFactoryRegistry->create([
                        'id' => $product->getUniqueIdentifier(),
                        'quantity' => 1,
                        'type' => 'product',
                        'stackable' => true,
                        'removable' => true,
                    ], $context);

                    $stellaAIAddedProduct = $product->getUniqueIdentifier();

                    $items[] = $item;
                } catch (CartException $e) {
                    if ($e->getErrorCode() === CartException::CART_INVALID_LINE_ITEM_QUANTITY_CODE) {
                        $this->addFlash(
                            self::DANGER,
                            $this->trans(
                                'error.CHECKOUT__CART_INVALID_LINE_ITEM_QUANTITY',
                                [
                                    '%quantity%' => $e->getParameter('quantity'),
                                ]
                            )
                        );

                        return $this->createActionResponse($request);
                    }

                    if ($e->getErrorCode() !== CartException::CART_LINE_ITEM_TYPE_NOT_SUPPORTED_CODE) {
                        throw $e;
                    }
                }
            }

            $cart = $this->cartService->add($cart, $items, $context);

            foreach ($cart->getLineItems()->getElements() as $lineItem) {
                if ($lineItem->getReferencedId() === $stellaAIAddedProduct) {
                    $lineItem->setPayloadValue('stella-ai-product', true);
                }
            }
            $this->cartService->recalculate($cart, $context);

            if (!$this->traceErrors($cart)) {
                $this->addFlash(self::SUCCESS, $this->trans('checkout.addToCartSuccess', ['%count%' => 1]));
            }
        } catch (ProductNotFoundException|RoutingException) {
            $this->addFlash(self::DANGER, $this->trans('error.addToCartError'));
        }

        return $this->createActionResponse($request);
    }

    private function traceErrors(Cart $cart): bool
    {
        if ($cart->getErrors()->count() <= 0) {
            return false;
        }

        $this->addCartErrors($cart, fn(Error $error) => $error->isPersistent());

        return true;
    }


    public function confirmPage(Request $request, SalesChannelContext $context): Response
    {
        if (!$context->getCustomer()) {
            return $this->redirectToRoute('frontend.checkout.register.page');
        }

        if ($this->cartService->getCart($context->getToken(), $context)->getLineItems()->count() === 0) {
            $customer = $context->getCustomer();
            if ($customer->getOrderCount() > 0) {
                $criteria = new Criteria();
                $criteria->addFilter(new EqualsFilter('orderCustomer.customerId', $customer->getId()));
                $criteria->addSorting(new FieldSorting('createdAt', 'DESC'));
                $criteria->addFilter(new EqualsFilter('transactions.stateMachineState.technicalName', 'in_progress'));
                /** @var OrderEntity|null $order */
                $order = $this->orderRepository->search($criteria, $context->getContext())->first();

                if ($order !== null) {
                    return $this->redirectToRoute('frontend.account.edit-order.page', ['orderId' => $order->getId()]);
                }
            }

            return $this->redirectToRoute('frontend.checkout.cart.page');
        }

        return $this->decorated->confirmPage($request, $context);
    }

    /**
     * @param Request $request
     * @param SalesChannelContext $context
     * @param RequestDataBag<string,mixed> $dataBag
     * @return Response
     */
    public function finishPage(Request $request, SalesChannelContext $context, RequestDataBag $dataBag): Response
    {
        return $this->decorated->finishPage($request, $context, $dataBag);
    }

    /**
     * @param RequestDataBag<string,mixed> $data
     * @param SalesChannelContext $context
     * @param Request $request
     * @return Response
     */
    public function order(RequestDataBag $data, SalesChannelContext $context, Request $request): Response
    {
        return $this->decorated->order($data, $context, $request);
    }

    public function info(Request $request, SalesChannelContext $context): Response
    {
        return $this->decorated->info($request, $context);
    }

    public function offcanvas(Request $request, SalesChannelContext $context): Response
    {
        return $this->decorated->offcanvas($request, $context);
    }
}
