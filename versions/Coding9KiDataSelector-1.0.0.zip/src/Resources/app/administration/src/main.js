import './module/kidata-selector';
